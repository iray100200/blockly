const path = require('path')
const root = path.resolve(__dirname) 
const HtmlWebpackPlugin = require('html-webpack-plugin')

module.exports = {
  entry: {
    demo: './src/main'
  },
  output: {
    path: path.join(root, 'dist'),  
    filename: '[name]-[hash].js'
  },
  resolve: {
    extensions: ['.js', '.jsx', '.json']
  },
  mode: 'development',
  devtool: 'source-map',
  module: {
    rules: [
      {
        test: /\.jsx?$/,
        exclude: /node_modules/,
        loader: 'babel-loader'
      },
      {
        test: /\.s[a|c]ss$/,
        loader: 'css-loader!sass-loader'
      },
      {
        test: /\.css$/,
        use: 'css-loader'
      },
      {
        test: /\.(woff2?|eot|ttf|otf|svg)(\?.*)?$/,
        loader: 'url-loader'
      }
    ]
  },
  plugins: [
    new HtmlWebpackPlugin({
      filename: 'index.html',
      template: './index.html',
      inject: true
    })
  ]
}