import React, { Component } from 'react'
import * as asyncEval from 'async-eval'

import './index.scss'

export default class App extends Component {
  constructor() {
    super()
  }
  componentDidMount() {
    // let temp = async function () { }
    // let AsyncFunction = Object.getPrototypeOf(temp).constructor
    // window.addEventListener('execBlockly', e => {
    //   let func = new AsyncFunction(e.detail)
    //   (async () => {
    //     func()
    //   })()
    // })
  }
  render() {
    return <div></div>
  }
}